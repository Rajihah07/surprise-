<?php
// Sambung ke pangkalan data
$conn = new mysqli("localhost", "root", "", "birthday_system");

// Semak jika ada masalah sambungan
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Dapatkan input mesej dari borang
$name = $_POST['name'];
$message = $_POST['message']; // Pastikan ini tanpa limit

// Simpan mesej ke dalam pangkalan data
$sql = "INSERT INTO messages (name, message) VALUES ('$name', '$message')";

if ($conn->query($sql) === TRUE) {
    echo "Mesej berjaya dihantar";
} else {
    echo "Ralat: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
